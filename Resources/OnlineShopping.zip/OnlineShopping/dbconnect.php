<?php 
	$host='isa-ebs-php-rds.c1mywycaa4au.us-east-1.rds.amazonaws.com';
	$username='root';
	$pass='root1234';
	$db='amaclone';

	$conn=mysqli_connect($host,$username,$pass,$db);

	if(!$conn) die("Connection refused").mysql_connect_error();
	else echo "DB connected successfully";
 ?>